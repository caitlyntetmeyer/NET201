﻿# ARRAY CHALLENGE:
Create an array of three tv shows that you like. 

<!--
var tvShows =
    new []
    {
        "Doctor Who",
        "Torchwood",
        "Game of Thrones"
    };
-->

# LIST CHALLENGE:
Create a list of strings that lists the winners of the Indy 500.

<!--
var indy500Winners =
    new List<string>
    {
        "Alexander Rossi",
        "Juan Pablo Montoya",
        "Ryan Hunter-Reay",
        "Tony Kanaan",
        "Dario Franchitti"
    };
-->